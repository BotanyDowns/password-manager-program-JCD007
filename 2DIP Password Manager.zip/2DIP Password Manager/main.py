#--------------------------------------------------     tkinter     --------------------------------------------------#

import tkinter as tk
from tkinter import *
from tkinter import font
from tkinter import ttk
from tkinter import messagebox
window = tk.Tk()

#--------------------------------------------------     Variables     --------------------------------------------------#

accounts = []
account_names = []
account = ""
password = ""
user_input = ""
username = ""
account_name = ""
reg_username = ""
reg_password = ""
register = ""
login_reg_username = ""
login_reg_password = ""
y = 0

#--------------------------------------------------     Functions     --------------------------------------------------#

def save_accounts():
    combo()
    with open(f"accountlist.txt", "w") as file:
        for account in accounts:
            account_name = account['Account ID']
            username = account['Login']
            password = account['Password']
            file.write(f"{account_name},{username},{password}\n")

def combo():
    global p2_combobox_delete
    p2_combobox_delete['values'] = [account['Account ID'] for account in accounts] if accounts else ["No accounts found"]
    p2_combobox_delete.current(0)

    global p2_combobox_view
    p2_combobox_view['values'] = [[account['Account ID'], account['Login'], account['Password']] for account in accounts] if accounts else ["No accounts found"]
    p2_combobox_view.current(0)

def print_accounts():
    global account_names, accounts, account
    with open("accountlist.txt", "r") as file:
        for line in file:
            line = line.strip()
            try:
                account_name, username, password = line.split(',')
                account = {'Account ID': account_name, 'Login': username, 'Password': password}
                accounts.append(account)
                account_name = {'Account ID': account_name}
                account_names.append(account_name)
            except ValueError:
                print(f"Skipping account line '{line}': invalid format")
                return
            
def userAdd():
    global account_name, username, password, account, accounts

    if not register_validate(p2_entry_name) or not register_validate(p2_entry_login) or not register_validate(p2_entry_password):
        messagebox.showerror("Error", "Account Name, Login, or Password cannot be empty.")
        return

    if messagebox.askyesno('Add Account', 'Are you sure you want to add this account?') == True:
        account_name = p2_entry_name.get()
        username = p2_entry_login.get()
        password = p2_entry_password.get()
        account = {'Account ID': account_name, 'Login': username, 'Password': password}
        accounts.append(account)
        p2_entry_name.delete(0, END)
        p2_entry_login.delete(0, END)
        p2_entry_password.delete(0, END)
        save_accounts()
        messagebox.showinfo("Account Added", "Account has been successfully added to the list.")
    else:
        return
    
def userQuit():
    if messagebox.askyesno("Quit Program", "Are you sure you want to quit to desktop?") == True:
        save_accounts()
        window.destroy()
    else:
        return

def userDelete():
    selected_account_id = p2_combobox_delete.get()
    selected_account = next((account for account in accounts if account['Account ID'] == selected_account_id), None)
    if selected_account:
        if messagebox.askyesno('Delete Account', 'Are you sure you want to delete this account?') == True:
            accounts.remove(selected_account)
            save_accounts()
            messagebox.showinfo("Account Removed", "Account has been successfully removed from the list.")
        else:
            return
    else:
        messagebox.showinfo("Account Error", "Sorry, this account could not be found")

    
def userLogin():
    global register, p1_entry_login, p1_entry_password, login_reg_username, login_reg_password
    login_reg_username = p1_entry_login.get()
    login_reg_password = p1_entry_password.get()

    if not register:
        messagebox.showerror("Login Failed", "Please register an account first.")
        return

    if not register_validate(p1_entry_login) or not register_validate(p1_entry_password):
        messagebox.showerror("Login Failed", "Login and Password cannot be empty.")
        return

    if login_reg_username in register['Login'] and login_reg_password in register['Password']:
        page2.grid()
        page1.grid_remove()
    else:
        messagebox.showerror("Login Failed", "The Login or Password you entered is incorrect. Please try again.")

def register_validate(entry):
    if len(entry.get()) == 0:
        return False
    else:
        return True

def userRegister():
    global register, reg_username, reg_password
    if not register_validate(p1_entry_login) or not register_validate(p1_entry_password):
        messagebox.showerror("Failed to Register Account", "Login and Password cannot be empty.")
        return

    if messagebox.askyesno("Register New Account", "This action will delete your current registered account and its contents, do you wish to proceed?") == True:
        with open(f"register.txt", "w") as file:
            file.write(f"{''}")
            reg_username = p1_entry_login.get()
            reg_password = p1_entry_password.get()
            register = {'Login': reg_username, 'Password': reg_password}
        with open(f"accountlist.txt", "w") as file:
            accounts.clear()
            file.write(f"")
            page2.grid()
            page1.grid_remove()
            reg_save_accounts()
            save_accounts()
            messagebox.showinfo("Account Registered","New account has been successfully been registered.")
    else:
        return

def reg_save_accounts():
    with open("register.txt", "w") as file:
        reg_username = p1_entry_login.get()
        reg_password = p1_entry_password.get()
        file.write(f'{reg_username},{reg_password}')

    with open("register.txt", "r") as file:
        for line in file:
            line = line.strip()
            try:
                global register
                reg_username, reg_password = line.split(',')
                register = {'Login': reg_username, 'Password': reg_password}
            except ValueError:
                return

def reg_print_accounts():
    global register, reg_password, reg_username
    with open("register.txt", "r") as file:
        for line in file:
            line = line.strip()
            try:
                reg_username, reg_password = line.split(',')
                register = {'Login': reg_username, 'Password': reg_password}
            except ValueError:
                return


reg_print_accounts()
print_accounts()
#--------------------------------------------------     Page 1     --------------------------------------------------#

page1 = Frame(window, width=100, highlightbackground='red',highlightthickness=3, pady=15,padx=15)
page1.grid(row=1, column=0,padx=10,pady=10)

p1_label_pm = Label(page1, text="Password Manager", font = ('bold', 18))
p1_label_pm.grid(row = 0, column = 0, pady=6,padx=6)

p1_label_account = Label(page1, text="Account Login", font = ('semibold', 14))
p1_label_account.grid(row = 1, column = 0, pady=6,padx=6)

p1_label_login = Label(page1, text="Login:", font = ('Arial', 8))
p1_label_login.grid(row = 2, column = 0,pady=6,padx=6)
p1_entry_login = Entry(page1)
p1_entry_login.grid(row = 3, column = 0,pady=3, padx=10)

p1_label_password = Label(page1, text="Password:", font = ('Arial', 8))
p1_label_password.grid(row = 4, column = 0,pady=6,padx=6)
p1_entry_password = Entry(page1)
p1_entry_password.grid(row = 5, column = 0,pady=3, padx=3)

p1_button_login = Button(page1, text = "Login", command=userLogin, font = ('semibold', 12))
p1_button_login.grid(row = 6, column = 0, sticky = W, pady=10, padx=10)

p1_button_register = Button(page1, text = "Register", command=userRegister, font = ('semibold', 12))
p1_button_register.grid(row = 6, column = 0,sticky = E, pady=10, padx=0)

p1_quit_button = Button(page1, text = "Quit", command=userQuit, font = ('semibold', 12))
p1_quit_button.grid(row = 8, column = 0, pady=3, padx=10)

#--------------------------------------------------     Page 2     --------------------------------------------------#

page2 = Frame(window, width=100, highlightbackground='red',highlightthickness=3, pady=15,padx=15)
page2.grid(row=1, column=0,padx=10,pady=10)

p2_label_pm = Label(page2, text="Password Manager", font = ('bold', 18))
p2_label_pm.grid(pady=6,padx=6)

p2_label_add = Label(page2, text="Add Account", font = ('semibold', 14))
p2_label_add.grid(pady=6,padx=6)

p2_label_name = Label(page2, text="Account Name:", font = ('Arial', 8))
p2_label_name.grid(pady=6,padx=6)
p2_entry_name = Entry(page2)
p2_entry_name.grid(pady=3, padx=10)

p2_label_login = Label(page2, text="Login:", font = ('Arial', 8))
p2_label_login.grid(pady=6,padx=6)
p2_entry_login = Entry(page2)
p2_entry_login.grid(pady=3, padx=10)

p2_label_password = Label(page2, text="Password:", font = ('Arial', 8))
p2_label_password.grid(pady=6,padx=6)
p2_entry_password = Entry(page2)
p2_entry_password.grid(pady=3, padx=10)

p2_button_add = Button(page2, text = "Add Account", command=userAdd, font = ('semibold', 12))
p2_button_add.grid(pady=3, padx=10)

p2_label_remove = Label(page2, text="Remove Account", font = ('semibold', 14))
p2_label_remove.grid(pady=6,padx=6)

if account: 
    p2_combobox_delete = ttk.Combobox(page2, values=[account['Account ID'] for account in accounts])
    p2_combobox_delete.current(0)
else:
    p2_combobox_delete = ttk.Combobox(page2, values=["No accounts found"]) 
p2_combobox_delete.grid(pady=3, padx=10)

p2_button_delete = Button(page2, text = "Delete", command=userDelete, font = ('semibold', 12))
p2_button_delete.grid(pady=3, padx=10)

p2_label_view = Label(page2, text="View Accounts", font = ('semibold', 14))
p2_label_view.grid(pady=6,padx=6)


if accounts: 
    account_values = [[account['Account ID'], account['Login'], account['Password']] for account in accounts]
    p2_combobox_view = ttk.Combobox(page2, values=account_values)
    p2_combobox_view.current(0)
else:
    p2_combobox_view = ttk.Combobox(page2, values=["No accounts found"]) 
p2_combobox_view.grid(pady=3, padx=20)

p2_button_quit = Button(page2, text = "Quit", command=userQuit, font = ('semibold', 12))
p2_button_quit.grid(pady=3, padx=10)

#--------------------------------------------------     idk     --------------------------------------------------#

page1.grid()
page2.grid_remove()
window.title('Frame Window')
window.geometry("281x600")  
window.grid()
window.resizable(False, False)

window.mainloop()